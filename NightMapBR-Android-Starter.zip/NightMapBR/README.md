# NightMap BR — Android

Projeto Android nativo em Kotlin + Jetpack Compose.

## Abrir
1. Extraia o ZIP.
2. Abra a pasta `NightMapBR` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute no emulador ou celular Android.

## Estado desta entrega
- Estrutura Android inicial.
- Interface de seleção em português.
- Tema escuro grafite/dourado.
- Modelo de domínio e motor de filtragem.
- Testes unitários básicos do motor.
- Arquivo de catálogo com esquema e atribuição preliminar.

## Dados
O catálogo `patterns.json` está intencionalmente vazio até validar a origem e os termos de reutilização dos 520 registros. A interface não deve apresentar uma seed como confirmada sem um registro real correspondente.

## Próximas etapas
1. Validar autorização/licença do conjunto de dados e atribuição.
2. Importar e validar os 520 padrões e os locais/variantes.
3. Integrar o carregador JSON e os resultados à interface.
4. Adicionar mapa visual interativo, detalhes e favoritos.
5. Gerar e testar o APK.

Projeto de fã independente. Não afiliado à FromSoftware ou Bandai Namco.
