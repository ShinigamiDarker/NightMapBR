package br.com.nightmap.domain

enum class ExpeditionMode { NORMAL, DEEP_OF_NIGHT }

enum class ShiftingEarth {
    LIMVELD, CRATER, MOUNTAINTOP, ROTTED_WOODS, NOKLATEO, GREAT_HOLLOW
}

data class MapPattern(
    val id: String,
    val nightlord: String,
    val shiftingEarth: ShiftingEarth,
    val deepOfNight: Boolean,
    val locations: Map<String, String>,
    val nightOneBoss: String? = null,
    val nightTwoBoss: String? = null,
    val specialEvent: String? = null
)

data class MapFilters(
    val mode: ExpeditionMode,
    val nightlord: String?,
    val shiftingEarth: ShiftingEarth,
    val observedLocations: Map<String, String>
)
