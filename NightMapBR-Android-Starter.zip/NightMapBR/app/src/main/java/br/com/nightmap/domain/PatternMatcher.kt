package br.com.nightmap.domain

object PatternMatcher {
    fun identify(patterns: List<MapPattern>, filters: MapFilters): List<MapPattern> =
        patterns.filter { pattern ->
            val modeMatches = pattern.deepOfNight ==
                (filters.mode == ExpeditionMode.DEEP_OF_NIGHT)
            val lordMatches = filters.nightlord == null ||
                pattern.nightlord.equals(filters.nightlord, ignoreCase = true)
            val regionMatches = pattern.shiftingEarth == filters.shiftingEarth
            val locationsMatch = filters.observedLocations.all { (location, value) ->
                pattern.locations[location] == value
            }
            modeMatches && lordMatches && regionMatches && locationsMatch
        }
}
