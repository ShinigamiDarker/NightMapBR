package br.com.nightmap

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF101216)
private val Panel = Color(0xFF1B2027)
private val Gold = Color(0xFFD4B16A)
private val Muted = Color(0xFF9AA3AE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NightMapTheme { NightMapHome() } }
    }
}

@Composable
private fun NightMapTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            onPrimary = Ink,
            background = Ink,
            surface = Panel,
            onSurface = Color(0xFFF0EEE8),
            secondary = Muted
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NightMapHome() {
    var mode by remember { mutableStateOf("Normal") }
    var lord by remember { mutableStateOf("Desconhecido") }
    var region by remember { mutableStateOf("Limveld") }
    var selected by remember { mutableStateOf(setOf<String>()) }

    val lords = listOf("Desconhecido", "Gladius", "Adel", "Gnoster", "Maris",
        "Libra", "Fulghor", "Caligo", "Heolstor", "Equilibradoras", "Lorde da Escória")
    val regions = listOf("Limveld", "A Cratera", "Pico da Montanha",
        "Floresta Apodrecida", "Noklateo", "O Grande Vazio")
    val landmarks = listOf(
        "Igreja", "Grande Igreja", "Ruínas", "Forte", "Acampamento principal",
        "Vila", "Aldeia de ferreiros", "Pântano", "Torre de feiticeiro",
        "Mercador", "Castelo", "Cárcere perpétuo"
    )

    Scaffold(containerColor = Ink, topBar = {
        TopAppBar(
            title = {
                Column {
                    Text("NIGHTMAP", color = Gold, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("BR  •  GUIA DE EXPEDIÇÕES", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
        )
    }) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("IDENTIFICAR MAPA", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            Text("Encontre o padrão da sua expedição.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Informe o que você sabe e marque apenas estruturas que conseguiu confirmar.", color = Muted)

            SectionCard("01  •  TIPO DE EXPEDIÇÃO") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Normal", "Profundezas da Noite").forEach {
                        FilterChip(
                            selected = mode == it,
                            onClick = { mode = it },
                            label = { Text(it) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Gold,
                                selectedLabelColor = Ink
                            )
                        )
                    }
                }
            }
            SectionCard("02  •  LORDE DA NOITE") {
                SimpleDropdown(lord, lords) { lord = it }
            }
            SectionCard("03  •  TERRA MUTÁVEL") {
                SimpleDropdown(region, regions) { region = it }
            }
            SectionCard("04  •  ESTRUTURAS IDENTIFICADAS") {
                Text("Toque nas estruturas que você viu no mapa.", color = Muted, fontSize = 13.sp)
                landmarks.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { landmark ->
                            val active = landmark in selected
                            FilterChip(
                                modifier = Modifier.weight(1f),
                                selected = active,
                                onClick = {
                                    selected = if (active) selected - landmark else selected + landmark
                                },
                                label = { Text(landmark, maxLines = 1) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Gold,
                                    selectedLabelColor = Ink
                                )
                            )
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
                Text("${selected.size} estrutura(s) marcada(s)", color = Gold, fontSize = 12.sp)
            }
            Button(
                onClick = { /* O motor será ligado ao catálogo validado na próxima etapa. */ },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("BUSCAR PADRÕES", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("BASE DE DADOS", color = Gold, fontWeight = FontWeight.Bold)
                    Text(
                        "A interface inicial está pronta. O catálogo real de 520 padrões será integrado após validação de origem, estrutura e atribuição dos dados.",
                        color = Muted, fontSize = 13.sp
                    )
                }
            }
            Text("Projeto independente de fãs • Não afiliado à FromSoftware ou Bandai Namco",
                color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SimpleDropdown(value: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = value,
            onValueChange = {},
            readOnly = true,
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Gold,
                unfocusedBorderColor = Color(0xFF414852)
            )
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(option) },
                    onClick = { onSelect(option); expanded = false }
                )
            }
        }
    }
}
