package br.com.nightmap.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class PatternMatcherTest {
    @Test
    fun filtersByLordRegionModeAndObservedLocation() {
        val patterns = listOf(
            MapPattern("000", "Gladius", ShiftingEarth.LIMVELD, false,
                mapOf("church" to "great_church")),
            MapPattern("001", "Adel", ShiftingEarth.LIMVELD, false,
                mapOf("church" to "church")),
            MapPattern("1000", "Gladius", ShiftingEarth.GREAT_HOLLOW, true,
                mapOf("village" to "blacksmith_village"))
        )
        val filters = MapFilters(
            mode = ExpeditionMode.NORMAL,
            nightlord = "Gladius",
            shiftingEarth = ShiftingEarth.LIMVELD,
            observedLocations = mapOf("church" to "great_church")
        )
        assertEquals(listOf("000"), PatternMatcher.identify(patterns, filters).map { it.id })
    }

    @Test
    fun emptyObservedLocationsDoesNotRemoveCandidates() {
        val patterns = listOf(
            MapPattern("000", "Gladius", ShiftingEarth.LIMVELD, false, emptyMap()),
            MapPattern("001", "Gladius", ShiftingEarth.LIMVELD, false, emptyMap())
        )
        val filters = MapFilters(ExpeditionMode.NORMAL, "Gladius", ShiftingEarth.LIMVELD, emptyMap())
        assertEquals(2, PatternMatcher.identify(patterns, filters).size)
    }
}
